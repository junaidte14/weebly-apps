{{! Enhanced Timeline v2.0.0 - Frontend Template }}
<div class="codotimeline_container" style="background-color: {{tmBgColor}};">

    <div class="codo_timeline" data-layout="{{timelineLayout}}">
        {{#numberOfElements_each}}
            <div class="codo_tm_container {{#if_layout_left}}left{{/if_layout_left}}{{#if_layout_right}}right{{/if_layout_right}}{{#if_layout_alternating}}{{#if_odd}}left{{/if_odd}}{{#if_even}}right{{/if_even}}{{/if_layout_alternating}}" 
                 data-index="{{numberOfElements_index}}"
                 style="padding-top: {{itemSpacing}}px; padding-bottom: {{itemSpacing}}px;">
                <div class="codo_tm_content" 
                     style="background-color: {{tmContentBGColor}}; 
                            border-radius: {{contentBorderRadius}}px;
                            padding: {{contentPadding}}px;">
                    {codo_elementct_{{numberOfElements_index}}:content default="Timeline Item {{numberOfElements_index}}. Add your content here. Click to edit this timeline entry and customize it with your own text, images, and formatting."}
                </div>
            </div>
        {{/numberOfElements_each}}
    </div>
</div>