/**
 * This is required for element rendering to be possible
 * @type {PlatformElement}
 *
 * we normalize the styles on initial load.
 */

(function() {
    var Breadcrumb = PlatformElement.extend({
        initialize: function() {
            // we normalize the styles on initial load.
            $(document).ready(function() {
                this.fixStyles();
                this.$el.children('.platform-element-overlay').hide();

                if($('.wsite-blog-index').length) {
                    $('.codo-crumb').hide();
                }

                if($('.wsite-blog-post').length) {
                    var post = $('.blog-title a');
                    $(post).clone().appendTo('.codo-crumb');
                }
                
            }.bind(this));

            this.fixStyles();
        },

        /**
         * Lots of styles are applied by default to editable areas of
         * the editor. To make the element looks how you want, some styles
         * need to be overwritten.
         */
        fixStyles: function() {
            this.$('.editable-text').each(function(index, value) {
                $(value).attr('style', '');
            });

            this.$('.element').each(function(index, value) {
                $(value).attr('style', '');
            });
        }
        
    });

    return Breadcrumb;
})();