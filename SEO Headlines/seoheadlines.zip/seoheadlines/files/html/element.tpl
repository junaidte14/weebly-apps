{{! template for the SEOHeadlines.}}
<div class="seoheadlines use-bg-color-{{useBgColor}}">
	<{{selectHeadline}} style="border: {{borderThickness}}px {{borderStyle}} {{borderColor}}; border-radius: {{borderRadius}}px;">
		{textheadline:text default="Edit Headline Text"}
	</{{selectHeadline}}>
</div>
