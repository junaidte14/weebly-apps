{{! template for the SEOHeadlines.}}
<div class="seoheadlines use-bg-color-{{useBgColor}}">
	<{{selectHeadline}} style="border: {{borderThickness}}px {{borderStyle}} {{borderColor}}; border-radius: {{borderRadius}}px;">
		{{headingText}}
	</{{selectHeadline}}>
</div>
